﻿angular.module("itsUser").controller("mainController", function ($scope, $http) {
    $scope.loginPage = true;
    $scope.signUp = false;
    $scope.viewUsers = false;                   /*!!!!!!!!!!!!!!! CHANGE - NEEDS TO BE FALSE !!!!!!!!!!!!!!!!!!!!*/
    $scope.step1 = false;
    $scope.step2 = false;
    $scope.step3 = false;
    $scope.success = false;
    $scope.bandSignUp = false;

    $scope.users = [                   /* Hard coded users- will need to be retrieved from somewhere*/
        //{
        //    id: 1,
        //    userName: 'Danny H',
        //    instrument: 'Triangle'
        //},
        //{
        //    id: 2,
        //    userName: 'Izzy M',
        //    instrument: 'guitar'
        //},
        //{
        //    id: 3,
        //    userName: 'Emma P',
        //    instrument: 'drums'
        //},
        //{
        //    id: 4,
        //    userName: 'Tasneem H',
        //    instrument: 'vocals'
        //}
    ];
    $scope.isAdding = false;

    //LOAD LIST OF USERS FROM API
    $scope.init = function () {
        $http.get("http://webteach_net.hallam.shu.ac.uk/b1023758/api/User")
            .success(function (response) {
                $scope.users = response;
            })
            .error(function (error) {
                $scope.errorMessage = error;
            });
    };
    $scope.init();
    $scope.regions = ["Argyll", "Cambridgeshire", "Yorkshire"];
    
   

    // Genre dropdown boxes 
    $scope.genreList = [];
    $scope.selectedGenre = null;
    //$scope.testGenres = [];
    $scope.fillGenreList = function () {
        $http.get("http://webteach_net.hallam.shu.ac.uk/b1023758/api/Genre")
            .success(function (result) {
                $scope.genreList = result;
            })
            .error(function (error) {
            $scope.errorMessage = error;
        });
    };
    $scope.fillGenreList();

    // Instrument dropdown boxes 
    $scope.instrumentList = [];
    $scope.selectedInstrument = null;
    //$scope.testGenres = [];
    $scope.fillInstrumentList = function () {
        $http.get("http://webteach_net.hallam.shu.ac.uk/b1023758/api/Instrument")
            .success(function (result) {
                $scope.instrumentList = result;
            })
            .error(function (error) {
                $scope.errorMessage = error;
            });
    };
    $scope.fillInstrumentList();

    // Instrument dropdown boxes 
    $scope.regionList = [];
    $scope.selectedRegion = null;
    //$scope.testGenres = [];
    $scope.fillRegionList = function () {
        $http.get("http://webteach_net.hallam.shu.ac.uk/b1023758/api/Region")
            .success(function (result) {
                $scope.regionList = result;
            })
            .error(function (error) {
                $scope.errorMessage = error;
            });
    };
    $scope.fillRegionList();

    // PASSWORD CONFIRMATION
    //$scope.isDisabled = true;
    //Confirm Password
    //$scope.error = false;
    //$scope.incomplete = false;
    //$scope.$watch('newPassword', function () { $scope.test(); });
    //$scope.$watch('confirmPwd', function () { $scope.test(); });
    //$scope.$test = function () {
    //    if ($scope.password !== $scope.confirmPwd) {
    //        $scope.error = true;
    //    }
    //    else {
    //        $scope.error = false;
    //    }
    //    $scope.incomplete = false;
    //};

    //GET LIST OF USERS
    $scope.add = function ()        // adding users to the list
    {

        var signUpDetails = {

            firstName: $scope.newFirstName,
            lastName: $scope.newLastName,
            username: $scope.newUserName,
            contactNo: $scope.newContact,
            email: $scope.newEmail,
            password: $scope.newPassword,
            regionId: $scope.selectedRegion,
            bioText: "test",
            availability: "actively looking",
            role: "normal",
            lastLogin: new Date(),
            dateJoined: new Date(),
            spotifyURL: "",
            imageURL: "",
            soundcloudURL: "",
            youtubeURL: ""

            //genre: $scope.selectedGenre,          
            //instrument: $scope.selectedInstrument
           


        };
        $http.post("http://webteach_net.hallam.shu.ac.uk/b1023758/api/User", signUpDetails)
            .success(function (response) {
                $scope.viewUsers = true;
                $scope.step3 = false;
                $scope.init();
                $scope.success = true;
            })
            .error(function (error) {
                $scope.errorMessage = error;
            });
        //$scope.users.push($scope.userName);
        //$scope.isAdding = false;
    };

    //SINGLE USER
    $scope.singleUser = [];


    //view user profile
    $scope.viewThisUserProfile = function (user) {
        $scope.viewUsers = false;
        $scope.viewUserProfile = true;
        $scope.contactRequestMade = false;
        $http.get("http://webteach_net.hallam.shu.ac.uk/b1023758/api/User/" + user.userId)
            .success(function (response) {
                $scope.singleUser = response;
            })
            .error(function (error) {
                $scope.errorMessage = error;
            });
    };

    $scope.viewThisUserProfile;
    $scope.requestContact = function () {
        $scope.contactRequestMade = true;
    };

    //BUTTON FUNCTIONS
    $scope.beginEditing = function ()      // used to click a button to toggle between different views
    {
        $scope.isAdding = true;
    };
    $scope.beginSignUp = function () {
        //$scope.signUp = true;
        $scope.step1 = true;
        $scope.step2 = false;
        $scope.loginPage = false;    /*!!!!!!!!!!!!!!!!!!!!!!CHANGE  - REMOVE LOGIN PAGE WHEN REGISTERING!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!*/
    };
    $scope.gostep2 = function () {
        $scope.step1 = false;
        $scope.step2 = true;
        $scope.step3 = false;
    };
    $scope.gostep3 = function () {
        $scope.step2 = false;
        $scope.step3 = true;
    };

    $scope.band_SignUp = function () {
        $scope.bandSignUp = true;
        $scope.loginPage = false;
    };
    $scope.cancelBand = function () {
        $scope.bandSignUp = false;
        $scope.loginPage = true;
    };

    $scope.cancelSignUp = function () {
        $scope.step1 = false;
        $scope.step2 = false;
        $scope.step3 = false;
        $scope.loginPage = true;      /*!!!!!!!!!!!!!!!!!!!!!!!!!!CHANGE - LOGIN PAGE SHOULD BE SET TO TRUE WHEN REGISTRATION CANCELLED!!!!!!!!!!!!!!!!!!!!!*/
    };

    $scope.cancelAddition = function ()     // cancel function 
    {
        $scope.isAdding = false;
        $scope.userName = "";
    };

    $scope.viewallusers = function ()           /*!!!!!!!!!!!!!!!!!!!!!!!CHANGE - ADD IN THIS FUNCTION!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!*/ {
        $scope.loginPage = false;
        $scope.viewUsers = true;
    };

    //!!!!!!!!!!!!!!!!!!!!!!!dannys changes!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!


    //HYPERLINK ENABLING - REQUIRED FOR ENABLING AN EXTERNAL LINK


    //HOW TO PULL THESE? - GOOGLE WORKS
    //spotify url fetching
    //$scope.spotifyurl = "singleUser.username";
    //youtube url fetching
    //$scope.youtubeurl = "singleUser.youtubeURL";
    //soundcloud url fetching
    //$scope.soundcloudurl = "singleUser.soundcloudURL";

    //test function - googleurl
    $scope.googleurl = "{{singleUser.spotifyURL}}";
    //passing the function results to the hyperlink
    $scope.linkModelFunc = function (url) {
        console.log('link model function');
        $window.open(url);
    };


    //NAV BAR FUNCTIONS:

    //---BROWSE USERS
    //consider expanding the viewallusers function to ensure all views containg the nav bar are set to false

    //---LOG OUT USER - will need to be expanded to accommodate all pages where this button can be clicked from
    $scope.logout = function () {
        $scope.viewUserProfile = false;
        $scope.viewusers = false;
        $scope.loginPage = true;
    };




});

