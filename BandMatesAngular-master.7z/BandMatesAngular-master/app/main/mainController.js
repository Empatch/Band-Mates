﻿angular.module("itsUser").controller("mainController", function ($scope, $http) {
    $scope.loginPage = true;
    $scope.signUp = false;
    $scope.viewUsers = false;                   
    $scope.viewBands = false;
    $scope.step1 = false;
    $scope.step2 = false;
    $scope.step3 = false;
    $scope.success = false;
    $scope.bandSignUp = false;
    $scope.editedUserDetails = false;
    $scope.isAdding = false;
    $scope.adminView = false;
    $scope.showWrongDetails = false;
    var editUserID;
    $scope.showUserInstruments = false;
    $scope.showAccMan = false;
    $scope.showRealLog = false;
    $scope.viewUserProfile = false;

    $scope.users = [];
    $scope.bands = [];

    //LOAD LIST OF USERS FROM API
    $scope.init = function () {
        $http.get("http://webteach_net.hallam.shu.ac.uk/b1023758/api/User")
            .success(function (response) {
                $scope.users = response;
                //$scope.getUserGenre(response.userId);
                
            })
            .error(function (error) {
                $scope.errorMessage = error;
            });
      
    };
    $scope.init();

    //Load list of bands
    $scope.bandinit = function () {
        $http.get("http://webteach_net.hallam.shu.ac.uk/b1023758/api/Band")
            .success(function (response) {
                $scope.bands = response;
            })
            .error(function (error) {
                $scope.errorMessage = error;
            });

    };
    $scope.bandinit();

    // Genre dropdown boxes 
    $scope.genreList = [];
    $scope.selectedGenre = null;
    $scope.fillGenreList = function () {
        $http.get("http://webteach_net.hallam.shu.ac.uk/b1023758/api/Genre")
            .success(function (result) {
                $scope.genreList = result;
            })
            .error(function (error) {
                $scope.errorMessage = error;
            });
    };
    //$scope.selectedGenreName = selectedGenre.genreName;
    //            $scope.selectedGenreId = ;

    $scope.fillGenreList();


    // Instrument dropdown boxes 
    $scope.instrumentList = [];
    $scope.selectedInstrument = null;
    $scope.fillInstrumentList = function () {
        $http.get("http://webteach_net.hallam.shu.ac.uk/b1023758/api/Instrument")
            .success(function (result) {
                $scope.instrumentList = result;
            })
            .error(function (error) {
                $scope.errorMessage = error;
            });
    };
    $scope.fillInstrumentList();

    // Region dropdown boxes 
    $scope.regionList = [];
    $scope.selectedRegion = null;
    $scope.fillRegionList = function () {
        $http.get("http://webteach_net.hallam.shu.ac.uk/b1023758/api/Region")
            .success(function (result) {
                $scope.regionList = result;
            })
            .error(function (error) {
                $scope.errorMessage = error;
            });
    };
    $scope.fillRegionList();

    // PASSWORD CONFIRMATION
    //$scope.isDisabled = true;
    //Confirm Password
    //$scope.error = false;
    //$scope.incomplete = false;
    //$scope.$watch('newPassword', function () { $scope.test(); });
    //$scope.$watch('confirmPwd', function () { $scope.test(); });
    //$scope.$test = function () {
    //    if ($scope.password !== $scope.confirmPwd) {
    //        $scope.error = true;
    //    }
    //    else {
    //        $scope.error = false;
    //    }
    //    $scope.incomplete = false;
    //};



    //GET LIST OF USERS
    $scope.add = function ()        // adding users to the list
    {

        var signUpDetails = {

            firstName: $scope.newFirstName,
            lastName: $scope.newLastName,
            username: $scope.newUserName,
            contactNo: $scope.newContact,
            email: $scope.newEmail,
            password: $scope.newPassword,
            regionId: $scope.selectedRegion,
            bioText: $scope.newUserBio,
            availability: "actively looking",
            role: "normal",
            lastLogin: new Date(),
            dateJoined: new Date(),
            spotifyURL: $scope.newSpotifyURL,
            imageURL: $scope.newImageURL,
            soundcloudURL: $scope.newSoundcloudURL,
            youtubeURL: $scope.newYoutubeURL

            //genre: $scope.selectedGenre,          
            //instrument: $scope.selectedInstrument



        };

        $http.post("http://webteach_net.hallam.shu.ac.uk/b1023758/api/User", signUpDetails)
            .success(function (response) {
                //$scope.userId = response.userId;
                $scope.init();
                $scope.viewUsers = true;
                //$scope.step3 = true;
                //$scope.step3 = false;
                $scope.success = true;
            })
            .error(function (error) {
                $scope.errorMessage = error;
            });
    };
    $scope.viewFilters = function (user) {
        $http.get("http://webteach_net.hallam.shu.ac.uk/b1023758/api/User/" + user.userId)
            .success(function (response) {
                //$scope.singleUser = response;
                editUserID = response.userId;
            })
            .error(function (error) {
                $scope.errorMessage = error;
            });

        $scope.step3 = true;
        $scope.viewallusers = false;
    };
    //ADDING GENRE and Instrument TO ACCOUNT currently hard coded
    $scope.addFilters = function () {

        //ADDED 
        var userGenre = {
            userId: editUserID,
            genreId: $scope.selectedGenre.genreId,
            genreName: $scope.selectedGenre.genreName
        };
        $http.post("http://webteach_net.hallam.shu.ac.uk/b1023758/api/UserGenre/", userGenre)
            .success(function (response) {
                $scope.getUserGenre(editUserID);
            })
            .error(function (error) {
                $scope.errorMessage = error;
            });


        var userInstrument = {
            userId: editUserID,
            instrumentId: $scope.selectedInstrument.instrumentId,
            instrumentName: $scope.selectedInstrument.instrumentName

        };
        $http.post("http://webteach_net.hallam.shu.ac.uk/b1023758/api/UserInstrument/", userInstrument)
            .success(function (response) {
                $scope.getUserInstrument(editUserID);
            })
            .error(function (error) {
                $scope.errorMessage = error;
            });

    };





    //SINGLE USER
    $scope.singleUser = [];
    $scope.userInstruments = [];
    $scope.userGenres = [];
    var thisUserId;

    //view user profile
    $scope.viewThisUserProfile = function (user) {
        $scope.loginPage = false;
        $scope.signUp = false;
        $scope.viewUsers = false;
        $scope.viewBands = false;
        $scope.step1 = false;
        $scope.step2 = false;
        $scope.step3 = false;
        $scope.success = false;
        $scope.bandSignUp = false;
        $scope.editedUserDetails = false;
        $scope.isAdding = false;
        $scope.adminView = false;
        $scope.showWrongDetails = false;
        var editUserID;
        $scope.showUserInstruments = false;
        $scope.showAccMan = false;
        $scope.showRealLog = false;
        $scope.viewUserProfile = true;
        $scope.contactRequestMade = false;
        $http.get("http://webteach_net.hallam.shu.ac.uk/b1023758/api/User/" + user.userId)
            .success(function (response) {
                console.log("HERE 1");
                $scope.getUserGenre(response.userId);
                console.log("HERE 2");
                $scope.getUserInstrument(response.userId);
                $scope.singleUser = response;
                thisUserId = response.userId;
            })
            .error(function (error) {
                $scope.errorMessage = error;
            });
    };

    $scope.viewThisUserProfile;
    $scope.viewGenres = function (user) {
        $scope.adminView = false;
        $scope.viewUsers = false;
        $scope.showUserInstruments = true;
        $http.get("http://webteach_net.hallam.shu.ac.uk/b1023758/api/UserInstrument/" + user.userId)
            .success(function (result) {
                $scope.userInstrument = result;

            })
            .error(function (error) {
                $scope.errorMessage = error;
            });
    };
    $scope.viewGenres;

    $scope.getUserDetails = function (userId) {
        $http.get("http://webteach_net.hallam.shu.ac.uk/b1023758/api/User/" + userId)
            .success(function (response) {
                $scope.thisUserDetails = response;
            })
            .error(function (error) {
                $scope.errorMessage = error;
            });
    };
    $scope.getUserDetails;
    $scope.getUserGenre = function (userId) {

        //ATTEMPT TO DISPLAY GENRE AND INSTRUMENT NOT WORKING
        $http.get("http://webteach_net.hallam.shu.ac.uk/b1023758/api/UserGenre/" + userId)
            .success(function (genres) {
                $scope.userGenres = genres;
            })
            .error(function (error) {
                $scope.errorMessage = error;
            });
    };
    $scope.getUserInstrument = function (userId) {
        $http.get("http://webteach_net.hallam.shu.ac.uk/b1023758/api/UserInstrument/" + userId)
            .success(function (instruments) {
                $scope.userInstruments = instruments;
            })
            .error(function (error) {
                $scope.errorMessage = error;
            });

    };
    $scope.getUserGenre;
    $scope.getUserInstrument;

    $scope.requestContact = function () {
        $scope.contactRequestMade = true;
    };

    //Editing Details for User
    $scope.displayEditUserDetails = function (userId) {
        $scope.editingUserDetails = true;
        $scope.showUserInstruments = true;
        $scope.showUserGenres = true;

        $http.get("http://webteach_net.hallam.shu.ac.uk/b1023758/api/User/" + userId)
            .success(function (response) {
                $scope.editFirstName = response.firstName;
                $scope.editLastName = response.lastName;
                $scope.editUserBio = response.bioText;
                $scope.editEmail = response.email;
                $scope.editContactNo = response.contactNo;
                editUserID = response.userId;
                $scope.editSelectedRegion = response.regionId;
                $scope.editPassword = response.password;
                $scope.editSpotify = response.spotifyURL;
                $scope.editPic = response.imageURL;
                $scope.editYoutube = response.youtubeURL;
                $scope.editSoundcloud = response.soundcloudURL;



            })
            .error(function (error) {
                $scope.errorMessage = error;
            });

    };

    $scope.editUser = function () {
        var editedUserDetails = {
            userId: editUserID,
            firstName: $scope.editFirstName,
            lastName: $scope.editLastName,
            email: $scope.editEmail,
            contactNo: $scope.editContactNo,
            bioText: $scope.editUserBio,
            regionId: $scope.editSelectedRegion,
            availability: "actively looking",
            role: "normal",
            //lastLogin: Date(),
            //dateJoined: Date(),
            spotifyURL: $scope.editSpotify,
            imageURL: $scope.editPic,
            soundcloudURL: $scope.editSoundcloud,
            youtubeURL: $scope.editYoutube,
            password: $scope.editPassword

        };
        $http.put("http://webteach_net.hallam.shu.ac.uk/b1023758/api/User/", editedUserDetails)
            .success(function () {
                $scope.displayEditUserDetails = false;
                //$scope.viewThisUserProfile(editUserID); 

            })
            .error(function (error) {
                $scope.errorMessage = error;
            });

    };

    //Remove Genres
    $scope.removeGenre = function (userGenre) {
        $http.delete("http://webteach_net.hallam.shu.ac.uk/b1023758/api/UserGenre?userId=" + userGenre.userId + "&genreId=" + userGenre.genreId)
            .success(function () {
                $scope.getUserGenre(userGenre.userId);
            })
            .error(function (error) {
                $scope.errorMessage = error;
            });
        //var itineraryToRemove = $scope.itineraries.indexOf(itineraryId);
        //$scope.itineraries.splice(itineraryToRemove, 1);
    };

    $scope.removeInstrument = function (userInstrument) {
        $http.delete("http://webteach_net.hallam.shu.ac.uk/b1023758/api/UserInstrument?userId=" + userInstrument.userId + "&instrumentId=" + userInstrument.instrumentId)
            .success(function () {
                $scope.getUserInstrument(userInstrument.userId);
            })
            .error(function (error) {
                $scope.errorMessage = error;
            });
        //var itineraryToRemove = $scope.itineraries.indexOf(itineraryId);
        //$scope.itineraries.splice(itineraryToRemove, 1);
    };

    $scope.cancelEdit = function () {
        $scope.editingUserDetails = false;
        $scope.showUserInstruments = false;
        $scope.showUserGenres = false;

    };
    //BUTTON FUNCTIONS

    $scope.showAdminView = function () {
        $scope.loginPage = false;
        $scope.adminView = true;
        $scope.viewUsers = false;
    };

    $scope.beginSignUp = function () {
        //$scope.signUp = true;
        $scope.step1 = true;
        $scope.step2 = false;
        $scope.loginPage = false;    /*!!!!!!!!!!!!!!!!!!!!!!CHANGE  - REMOVE LOGIN PAGE WHEN REGISTERING!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!*/
        $scope.showRealLog = false;
    };
    $scope.gostep2 = function () {
        $scope.step1 = false;
        $scope.step2 = true;
        $scope.step3 = false;
    };
    $scope.gostep3 = function () {
        $scope.step2 = false;
        $scope.step3 = true;
    };

    $scope.band_SignUp = function () {
        $scope.loginPage = false;
        $scope.signUp = false;
        $scope.viewUsers = false;
        $scope.viewBands = false;
        $scope.step1 = false;
        $scope.step2 = false;
        $scope.step3 = false;
        $scope.success = false;
        $scope.bandSignUp = true;
        $scope.editedUserDetails = false;
        $scope.isAdding = false;
        $scope.adminView = false;
        $scope.showWrongDetails = false;
        var editUserID;
        $scope.showUserInstruments = false;
        $scope.showAccMan = false;
        $scope.showRealLog = false;
    };
    $scope.cancelBand = function () {
        $scope.bandSignUp = false;
        $scope.loginPage = true;
    };

    $scope.cancelSignUp = function () {



        $scope.step1 = false;
        $scope.step2 = false;
        $scope.step3 = false;
        $scope.loginPage = true;      /*!!!!!!!!!!!!!!!!!!!!!!!!!!CHANGE - LOGIN PAGE SHOULD BE SET TO TRUE WHEN REGISTRATION CANCELLED!!!!!!!!!!!!!!!!!!!!!*/
    };

    //$scope.cancelAddition = function ()     // cancel function 
    //{
    //    $scope.isAdding = false;
    //    $scope.userName = "";
    //};
    $scope.showAuthenticationError = function () {
        $scope.showWrongDetails = true;
    };

    $scope.viewallusers = function ()           /*!!!!!!!!!!!!!!!!!!!!!!!CHANGE - ADD IN THIS FUNCTION!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!*/ {
        //$scope.loggedUserDetails = $scope.loggedusername.username;
        $scope.loginPage = false;
        $scope.signUp = false;
        $scope.viewUsers = true;
        $scope.viewBands = false;
        $scope.step1 = false;
        $scope.step2 = false;
        $scope.step3 = false;
        $scope.success = false;
        $scope.bandSignUp = false;
        $scope.editedUserDetails = false;
        $scope.isAdding = false;
        $scope.adminView = false;
        $scope.showWrongDetails = false;
        var editUserID;
        $scope.showUserInstruments = false;
        $scope.showAccMan = false;
        $scope.showRealLog = false;

    };

    $scope.viewallbands = function ()           /*!!!!!!!!!!!!!!!!!!!!!!!CHANGE - ADD IN THIS FUNCTION!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!*/ {
        //$scope.loggedUserDetails = $scope.loggedusername.username;
        $scope.loginPage = false;
        $scope.signUp = false;
        $scope.viewUsers = false;
        $scope.viewBands = true;
        $scope.step1 = false;
        $scope.step2 = false;
        $scope.step3 = false;
        $scope.success = false;
        $scope.bandSignUp = false;
        $scope.editedUserDetails = false;
        $scope.isAdding = false;
        $scope.adminView = false;
        $scope.showWrongDetails = false;
        var editUserID;
        $scope.showUserInstruments = false;
        $scope.showAccMan = false;
        $scope.showRealLog = false;
    };

    //!!!!!!!!!!!!!!!!!!!!!!!dannys changes!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!


    //HYPERLINK ENABLING - REQUIRED FOR ENABLING AN EXTERNAL LINK


    //HOW TO PULL THESE? - GOOGLE WORKS
    //spotify url fetching
    //$scope.spotifyurl = "singleUser.username";
    //youtube url fetching
    //$scope.youtubeurl = "singleUser.youtubeURL";
    //soundcloud url fetching
    //$scope.soundcloudurl = "singleUser.soundcloudURL";

    //test function - googleurl
    $scope.googleurl = "{{singleUser.spotifyURL}}";
    //passing the function results to the hyperlink
    $scope.linkModelFunc = function (url) {
        console.log('link model function');
        $window.open(url);
    };



    //---BROWSE USERS
    //consider expanding the viewallusers function to ensure all views containg the nav bar are set to false

    //---LOG OUT USER - will need to be expanded to accommodate all pages where this button can be clicked from
    $scope.logout = function () {
        $scope.loginPage = true;
        $scope.signUp = false;
        $scope.viewUsers = false;
        $scope.viewBands = false;
        $scope.step1 = false;
        $scope.step2 = false;
        $scope.step3 = false;
        $scope.success = false;
        $scope.bandSignUp = false;
        $scope.editedUserDetails = false;
        $scope.isAdding = false;
        $scope.adminView = false;
        $scope.showWrongDetails = false;
        var editUserID;
        $scope.showUserInstruments = false;
        $scope.showAccMan = false;
        $scope.showRealLog = false;
        $scope.viewUserProfile = false;
    };

    //Band sign up
    $scope.addBand = function () {

        var bandSignUpDetails = {
            //bandId: 6,
            regionId: $scope.selectedBandRegion.regionId,
            regionName: $scope.selectedBandRegion.regionName,
            genreId: $scope.selectedBandGenre.genreId,
            genreName: $scope.selectedBandGenre.genreName,
            bandName: $scope.newBandName,
            profilePhoto: $scope.newBandImageURL,
            bioText: $scope.newBandBio,
            spotifyURL: $scope.newBandSpotifyURL,
            YouTubeURL: $scope.newBandYoutubeURL,
            SoundCloudURL: $scope.newBandSoundcloudURL,
            email: $scope.newBandEmail,
            phone: $scope.newBandContact
            //genre: $scope.selectedGenre,          
            //instrument: $scope.selectedInstrument
        };

        $http.post("http://webteach_net.hallam.shu.ac.uk/b1023758/api/Band", bandSignUpDetails)
            .success(function (response) {
                //$scope.userId = response.userId;
                $scope.bandinit();
                $scope.adminView = true;

                $scope.success = true;
            })
            .error(function (error) {
                $scope.errorMessage = error;
            });
    };

    $scope.accMan = function () {
        $scope.loginPage = false;
        $scope.signUp = false;
        $scope.viewUsers = false;
        $scope.viewBands = false;
        $scope.step1 = false;
        $scope.step2 = false;
        $scope.step3 = false;
        $scope.success = false;
        $scope.bandSignUp = false;
        $scope.editedUserDetails = false;
        $scope.isAdding = false;
        $scope.adminView = false;
        $scope.showWrongDetails = false;
        $scope.showUserInstruments = false;
        $scope.showAccMan = true;
        $scope.showRealLog = false;
        $scope.viewUserProfile = false;
    };

    $scope.realLog = function () {
        $scope.loginPage = false;
        $scope.showRealLog = true;
    }


});

