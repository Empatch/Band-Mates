﻿angular.module("itsUser").controller("authenticationController", function ($scope, $http) {
    //$scope.name = [];
    //$scope.role = [];
    //$scope.authenticated = [];
    $scope.loggedUser = [];
    $scope.login = function () {
        var authenticationDetails = {
            username: $scope.username,
            password: $scope.password
        };
        $http.post("http://webteach_net.hallam.shu.ac.uk/b1023758/api/Login", authenticationDetails)
            .success(function (response) {
                //$scope.loggedUser = response;
                //console.log($scope.loggedUser);
                $scope.viewallusers();
                $scope.showRealLog = false;
                //var loggedUserDetails = {
                //    username: authenticationDetails.username,
                //    password: authenticationDetails.password
                //};

                //$scope.role = response;
                //$scope.authenticated = response;

              
                //var test = $scope.authenticated;
                $http.get("http://webteach_net.hallam.shu.ac.uk/b1023758/api/User/" + response.userId)
                    .success(function (response) {
                        $scope.getUserDetails(response.userId);
//$scope.loggedUser = response;
                        $scope.getUserGenre(response.userId);                       
                        $scope.getUserInstrument(response.userId);
                        
                        //console.log($scope.loggedUser);                        
                        thisUserId = response.userId;
                    })
                    .error(function (error) {
                        $scope.errorMessage = error;
                    });

            })
            .error(function (error) {
                $scope.errorMessage = error;
                
                $scope.showAuthenticationError();
            });
        
    };
   
    console.log("3: " + $scope.loggedusername);



});