﻿angular.module("itsUser").controller("mainController", function ($scope, $http) {
    $scope.loginPage = true;
    $scope.signUp = false;
    $scope.viewUsers = true;
    $scope.step1 = false;
    $scope.step2 = false;
    $scope.step3 = false;
    $scope.success = false;
    $scope.users = [                   /* Hard coded users- will need to be retrieved from somewhere*/
        //{
        //    id: 1,
        //    userName: 'Danny H',
        //    instrument: 'Triangle'
        //},
        //{
        //    id: 2,
        //    userName: 'Izzy M',
        //    instrument: 'guitar'
        //},
        //{
        //    id: 3,
        //    userName: 'Emma P',
        //    instrument: 'drums'
        //},
        //{
        //    id: 4,
        //    userName: 'Tasneem H',
        //    instrument: 'vocals'
        //}
    ];
    $scope.isAdding = false;
    $scope.init = function () {
        $http.get("http://webteach_net.hallam.shu.ac.uk/b1023758/api/User")
            .success(function (response) {
                $scope.users = response;
            })
            .error(function (error) {
                $scope.errorMessage = error;
            });
    };
    $scope.init();
    $scope.regions = ["Argyll", "Cambridgeshire", "Yorkshire"];
    $scope.instruments = ["Guitar", "Bass"];
    $scope.genres = ["Rock", "Country"];
    $scope.add = function ()        // adding users to the list
    {

        var signUpDetails = {

            firstName: $scope.newFirstName,
            lastName: $scope.newLastName,
            username: $scope.newUserName,
            contactNo: $scope.newContact,
            email: $scope.newEmail,
            password: $scope.newPassword,
            regionId: "1"/*$scope.selectedRegion*/,
            bioText: "test",
            availability: "actively looking",
            role: "normal",
            lastLogin: new Date(),
            dateJoined: new Date(),
            spotifyURL: "",
            imageURL: "",
            soundcloudURL: "",
            youtubeURL: "",

            //genre: "rock",
            //bandMembers: "aaaa",
            //instrument: "guitar",
            //request: "aaa"


        };
        $http.post("http://webteach_net.hallam.shu.ac.uk/b1023758/api/User", signUpDetails)
            .success(function (response) {
                $scope.viewUsers = true;
                $scope.step3 = false;
                $scope.init();
                $scope.success = true;
            })
            .error(function (error) {
                $scope.errorMessage = error;
            });

        //$scope.users.push($scope.userName);
        //$scope.isAdding = false;
    };
    $scope.beginEditing = function ()      // used to click a button to toggle between different views
    {
        $scope.isAdding = true;
    };
    $scope.beginSignUp = function () {
        //$scope.signUp = true;
        $scope.step1 = true;
        $scope.step2 = false;
    };
    $scope.gostep2 = function () {
        $scope.step1 = false;
        $scope.step2 = true;
        $scope.step3 = false;
    };
    $scope.gostep3 = function(){
        $scope.step2 = false;
        $scope.step3 = true;
    };
    $scope.cancelSignUp = function () {
        $scope.step1 = false;
        $scope.step2 = false;
        $scope.step3 = false;
    };
    
    $scope.cancelAddition = function ()     // cancel function 
    {
        $scope.isAdding = false;
        $scope.userName = "";
    };
});
