﻿angular.module("bmAuthentication").controller("authenticationController", function ($scope, $http) {
    //$scope.name = [];
    //$scope.role = [];
    //$scope.authenticated = [];
    
    $scope.login = function () {
        var authenticationDetails = {
            username: $scope.username,
            password: $scope.password
        };
        $http.post("http://webteach_net.hallam.shu.ac.uk/b1023758/api/Login", authenticationDetails)
            .success(function (response) {
                
                //$scope.role = response;
                //$scope.authenticated = response;

              
                //var test = $scope.authenticated;


            })
            .error(function (error) {
                $scope.errorMessage = error;
            });

    };



});